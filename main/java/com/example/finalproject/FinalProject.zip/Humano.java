package com.example.finalproject;

public class Humano extends Heroi {

    public Humano (String nome, int vida, int armadura){
        super(nome, vida, armadura);
    }
}

