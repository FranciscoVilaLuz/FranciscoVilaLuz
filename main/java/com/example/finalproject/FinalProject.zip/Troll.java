package com.example.finalproject;

public class Troll extends Besta {

    public Troll (String nome, int vida, int armadura){

        super(nome, vida, armadura);
    }
}
